// 로고 클릭 시 메인으로 이동
function goHome() {
    window.location.href = 'main.html';
}